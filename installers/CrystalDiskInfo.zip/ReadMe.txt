/*---------------------------------------------------------------------------*/
//      Product : CrystalDiskInfo 8
//       Author : hiyohiyo
//         Mail : hiyohiyo@crystalmark.info
//          Web : https://crystalmark.info/
//      License : The MIT License
/*---------------------------------------------------------------------------*/

== Standard Edition ==
DiskInfo32.exe   : 32bit (x86)
DiskInfo64.exe   : 64bit (x64)
DiskInfoA32.exe  : 32bit (ARM32)
DiskInfoA64.exe  : 64bit (ARM64)

== Shizuku Edition ==
DiskInfo32S.exe  : 32bit (x86)
DiskInfo64S.exe  : 64bit (x64)
DiskInfoA32S.exe : 32bit (ARM32)
DiskInfoA64S.exe : 64bit (ARM64)

== Kurei Kei Edition ==
DiskInfo32K.exe  : 32bit (x86)
DiskInfo64K.exe  : 64bit (x64)
DiskInfoA32K.exe : 32bit (ARM32)
DiskInfoA64K.exe : 64bit (ARM64)

== OS ==
OK: Windows XP/Vista/7/8/8.1/10/2003/2008/2012/2016/2019
NG: Windows 95/98/Me/NT4/2000

32bit (x86)   : Windows XP/Vista/7/8/8.1/10/2003/2008/2012/2016/2019
64bit (x64)   : Windows Vista/7/8/8.1/10/2008/2012/2016/2019
32bit (ARM32) : Windows 10
64bit (ARM64) : Windows 10